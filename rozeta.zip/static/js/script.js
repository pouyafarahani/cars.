$('#hamburger').click (function(){
    $('.navigation-manu').toggleClass('open');
  });
  